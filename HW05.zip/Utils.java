package edu.cofc.cs.csci230;

/**
 * Utilities class that will sort (in increasing order)
 * the elements of a list.
 *
 * The sorting algorithms supported in this class are:
 *	1. selection sort
 *	2. bubble sort
 *	3. insertion sort
 * 
 * @author CSCI 230: Data Structures and Algorithms Fall 2016
 *
 */
public class Utils {
	
	/**
	 * 
	 */
	private Utils() {
		
	} // end private constructor
	
	/**
	 * 
	 * @param list
	 */
	public static <AnyType extends Comparable> void selectionSort( List<AnyType> list ) throws IndexOutOfBoundsException {
		
		/* TODO:
		 * ----------------------------------------
		 * Implement selection sort algorithm as
		 * described in class. The pseudo-code
		 * for this algorithm can be found in 
		 * the content section on OAKS.
		 * 
		 */
		
		for ( int i = 0; i < list.size() - 1; i++) {
			int min = i;
			for (int j = i + 1; j < list.size(); j++) {
				AnyType tempA = list.get(j);
				AnyType tempB = list.get(min);
				if (tempA.compareTo(tempB) < 0) {
					min = j;
				}
			}
			list.swap(min, i);
		}
		
	} // end selectionSort() method
	
	/**
	 * 
	 * @param list
	 */
	public static <AnyType extends Comparable> void bubbleSort( List<AnyType> list ) throws IndexOutOfBoundsException {
		
		/* TODO:
		 * ---------------------------------------
		 * Implement bubble sort algorithm as
		 * described in class. The pseudo-code
		 * for this algorithm can be found in 
		 * the content section on OAKS.
		 * 
		 */
		
		for ( int i = 0; i < list.size() - 1; i++) {
			for ( int j = 0; j < (list.size() - 1 - i); j++) {
				AnyType tempA = list.get(j + 1);
				AnyType tempB = list.get(j);
				if (tempA.compareTo(tempB) < 0) {
					list.swap(j, j + 1);
				}
			}
		}
		
	} // end bubbleSort() method
	
	/**
	 * 
	 * @param list
	 */
	public static <AnyType extends Comparable> void insertionSort( List<AnyType> list ) throws IndexOutOfBoundsException {
		
		/* TODO:
		 * ----------------------------------------
		 * Implement insertion sort algorithm as
		 * described in class and in the course 
		 * textbook. The pseudo-code for this 
		 * algorithm can also be found in 
		 * the content section on OAKS.
		 * 
		 */
		
		for ( int i = 1; i < list.size(); i++ ) {
			AnyType tempA = list.get(i);
			int j = i - 1;
			while (j >= 0 && (list.get(j).compareTo(tempA) > 0)) {
				list.set(j + 1, list.get(j));
				j = j - 1;
			}
			list.set(j + 1, tempA);
		}
		
	} // end insertionSort() method
	
} // end Utils class definition
